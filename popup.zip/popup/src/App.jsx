import React from "react";
import ErrorBoundary from "./ErrorBoundary";
import ProblematicMath from "./ProblematicMath";
import Login from "./Login"; 

const App = () => {
  return (
    <div>
      <Login />
      <ErrorBoundary>
        <ProblematicMath />
      </ErrorBoundary>
    </div>
  );
};

export default App;
