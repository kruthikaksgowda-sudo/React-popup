import React from "react";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMessage: "" };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, errorMessage: error.message };
  }

  componentDidCatch(error, info) {
    console.error("Caught by Error Boundary:", error, info);
  }

  handleReset = () => {
    this.setState({ hasError: false, errorMessage: "" });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            textAlign: "center",
            color: "white",
            backgroundColor: "red",
            padding: "20px",
            borderRadius: "10px",
            margin: "100px auto",
            width: "300px",
          }}
        >
          <h3>Invalid Operation!</h3>
          <p>{this.state.errorMessage}</p>
          <button
            onClick={this.handleReset}
            style={{
              backgroundColor: "white",
              color: "red",
              padding: "8px 15px",
              borderRadius: "5px",
              border: "none",
              cursor: "pointer",
              marginTop: "10px",
            }}
          >
            Try Again
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
