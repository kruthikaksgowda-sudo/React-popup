import React, { useState } from "react";
import ReactDOM from "react-dom";

const Login = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  
  const handleLogin = (e) => {
    e.preventDefault();
    setIsLoggedIn(true);
    setTimeout(() => setIsLoggedIn(true),100); 
  };

  const loginUI = (
    <div
      style={{
        position: "fixed",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        background: "#f5f5f52a",
        padding: "30px",
        borderRadius: "10px",
        boxShadow: "0 0 10px rgba(0,0,0,0.2)",
        textAlign: "center",
      }}
    >
      <h2>Login Page </h2>
      <form onSubmit={handleLogin}>
        <input
          type="text"
          placeholder="Username"
          style={{ margin: "10px", padding: "8px", width: "200px" }}
          required
        />
        <br />
        <input
          type="password"
          placeholder="Password"
          style={{ margin: "10px", padding: "8px", width: "200px" }}
          required
        />
        <br />
        <button
          type="submit"  onClick={()=>setIsLoggedIn(true)}
          style={{
            marginTop: "10px",
            padding: "8px 16px",
            background: "#4faf4cff",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Submit
        </button>
      </form>

      {isLoggedIn && (
        <div
          style={{
            marginTop: "20px",
            color: "white",
            background: "#4c63afff",
            padding: "10px",
            borderRadius: "5px",
          }}
        >
          Login Successful! 
          <button
          type="close"  onClick={()=>setIsLoggedIn(false)}
          style={{
            marginTop: "10px",
            padding: "8px 16px",
            background: "#af4f4cff",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          close popup
          <br/>
        </button>
          
        </div>
      )}
    </div>
  );

  return  ReactDOM.createPortal(loginUI, document.getElementById("portal-root"));

};

export default Login;