import React, { useState } from "react";

const ProblematicMath = () => {
  const [expression, setExpression] = useState("");
  const [result, setResult] = useState(null);

  const calculate = () => {
    try {
      if (!expression.trim()) {
        throw new Error("Please enter a mathematical expression.");
      }

      if (!/^[0-9+\-*/().\s]+$/.test(expression)) {
        throw new Error("Invalid characters in expression!");
      }
      let res = Function(`"use strict"; return (${expression})`)();

      if (!isFinite(res)) {
        throw new Error("Division by zero or invalid operation!");
      }

      setResult(res);
    } catch (err) {
      throw new Error(`Syntax or Math Error: ${err.message}`);
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" ,backgroundColor:"white"}}>
      <h3 style={{ textAlign: "center", marginTop: "50px" ,backgroundColor:"black"}}>Math Expression Evaluator</h3>
      <input
        type="text"
        placeholder="Enter expression (e.g., 2+4)"
        value={expression}
        onChange={(e) => setExpression(e.target.value)}
        style={{ width: "250px", margin: "10px", padding: "5px" , background: "rgba(211, 211, 211, 0.25)"}}
      />
      <br />
      <button 
       type="calculate"onClick={calculate} style={{ margin: "5px", padding: "5px 10px", background: "#4faf4cff",
            color: "white", }}>
        Calculate
      </button>

      {result !== null && <h3>Result: {result}</h3>}
    </div>
  );
};

export default ProblematicMath;
